# Minor Hockey Association - Model

## Admin
* User
* Person
* Role
** Official
*** Player
*** Coach
*** Trainer
*** Manager
** Admin


