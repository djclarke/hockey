package hockey.model.events;

import hockey.model.BaseEntity;

public class PersonAttendance extends BaseEntity {

}
