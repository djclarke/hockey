package hockey.model.events;

public class OtherEvent extends Event {

}
