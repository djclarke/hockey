package hockey.model.events;

public class Practice extends Event {

}
