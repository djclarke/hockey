package hockey.model.team;

import hockey.model.BaseEntity;

import javax.persistence.Entity;

@Entity
public class Player extends BaseEntity {


}
